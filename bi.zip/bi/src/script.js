function openEnvelope() {
  const envelope = document.querySelector('.envelope');
  const content = document.querySelector('.content');

  envelope.classList.add('hidden'); // Hide the envelope
  content.classList.remove('hidden'); // Show the content
}
